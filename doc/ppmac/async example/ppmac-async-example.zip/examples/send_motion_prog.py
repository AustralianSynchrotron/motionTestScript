"""
example send motion program
"""

import time
from ppmac_async import PpmacGpascii
import os

prog_name = "ssh_motion_prog" # this motion program name must already exist and not be running

HOST = os.getenv("PPMAC_TEST_IP")
assert HOST != None, "need ENV var = PPMAC_TEST_IP"
filename = "./examples/example_motion_prog1.nc"


with open(filename, 'r') as fi:
    buffer = fi.readlines()

ppmac = PpmacGpascii(host=HOST)
ppmac.connect()
ppmac.send_motion_prog(prog_name, buffer)
ppmac.close()

# trying to readback the prog immediately after sending will not work
# so you must close the connection and reconnect
ppmac.connect()
buffer_read = ppmac.get_motion_prog(prog_name)
print(f"readback:\n{buffer_read}")
ppmac.close()

# remove empty lines and comments before comparing
buffer_in = ppmac.remove_comments(buffer)

buffer_out = ppmac.remove_comments(buffer_read)

# you can't do a perfect compare without interpreting the program, so we print for manual comparison.
for i in range(len(buffer_in)):
    print(f"in:{buffer_in[i]} , out:{buffer_out[i]}")
