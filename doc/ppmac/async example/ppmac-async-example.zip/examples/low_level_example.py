import os
import time
from ppmac_async import PpmacGpascii


HOST = os.getenv("PPMAC_TEST_IP")
assert HOST != None, "need ENV var = PPMAC_TEST_IP"

print(f"connecting to ppmac = {HOST}")

def send_receive_with_print(ppmac, cmd):
    response_dict = ppmac.send_receive_low([cmd])

    # strip out the command strings.
    response = response_dict[cmd][1]
    # response_dict contains dictionary of commands sent, and their response.
   
    print(f"sent \" {cmd} \"")
    print(f"response \" {response} \"")
    return response

def get_pos(ppmac, chan):
    cmd = f"#{chan}p"
    pos = float(send_receive_with_print(ppmac, cmd))
    return pos

def move_to_pos(ppmac, chan, posn):
    cmd = f"#{chan}j={posn}"
    send_receive_with_print(ppmac, cmd)

def wait_till_done(ppmac, chan):
    cmd = f"motor[{chan}].inpos"
    inpos_state = int(send_receive_with_print(ppmac, cmd))
    while (inpos_state) != 1:
        inpos_state = int(send_receive_with_print(ppmac, cmd))
        time.sleep(0.1)

ppmac = PpmacGpascii(host=HOST)
ppmac.connect()

chan = 5

posn = get_pos(ppmac, chan)
posn += 1 # increment by 1 [mm]
move_to_pos(ppmac, chan, posn)

wait_till_done(ppmac, chan)

