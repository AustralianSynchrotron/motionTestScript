""" example use of the aioppmac routines """
import os
import asyncio
import time
from asyncppmac.aioppmac import AIOppmac


async def send_many(HOST):
    """send many commands"""

    NUM_CMDS = 100

    appmac = AIOppmac(HOST)
    await appmac.start()
    task1 = []
    task2 = []
    task3 = []
    task4 = []
    start_t = time.time()
    for j in range(NUM_CMDS):
        for i in range(8):
            task1.append(asyncio.create_task(
                appmac.send_receive(f"#{i+1}p")))

            task2.append(asyncio.create_task(
                appmac.send_receive(f"#{i+1}f")))
            task3.append(asyncio.create_task(
                appmac.send_receive(f"Motor[{i+1}].status[0]")))
            task4.append(asyncio.create_task(
                appmac.send_receive(f"Motor[{i+1}].status[1]")))
    # Wait until both tasks are completed (should take
    # around 2 seconds.)
    result1 = []
    result2 = []
    result3 = []
    result4 = []
    for j in range(NUM_CMDS):
        for i in range(8):
            result1.append(await task1[i])
            result2.append(await task2[i])
            result3.append(await task3[i])
            result4.append(await task4[i])
    fin_t = time.time()
    took = (fin_t - start_t)
    # print(result1)
    # print(result2)
    print(f"took={took*1000:.2f}ms, {32*NUM_CMDS/took:.0f}cmd/s")

    appmac.close()


def rum_multiple():
    """send many"""
    ppmac_test_IP = os.environ["PPMAC_TEST_IP"]
    loop = asyncio.get_event_loop()
    loop.run_until_complete(send_many(ppmac_test_IP))


if __name__ == '__main__':

    run_multiple()
