import os
import time

import pytest
import logging

from ppmac_async import PpmacGpascii

# def pytest_configure(config):
#     config.addinivalue_line(
#         "hardware", "include hardware test, have hardware."
#     )

# TODO add some "basic" (non-hardware) tests

@pytest.mark.hardware
def test_low_level():

    HOST = os.getenv("PPMAC_TEST_IP")
    assert HOST != None, "need ENV var = PPMAC_TEST_IP"
    
    ppmac = PpmacGpascii(host=HOST)
    ppmac.connect()

    num_samples = 100
    timeArray = []
    sum = 0

    cmd_list = []
    for j in range(8):
        cmd_list += [f"#{j%8+1}p "]
        cmd_list += [f"Motor[{j%8+1}].Status[0]"]
        cmd_list += [f"Motor[{j%8+1}].JogSpeed"]
        cmd_list += [f"Motor[{j%8+1}].PosError"]

    loop_start = time.time()
    start_time = time.time()
    received_ = 0
    for i in range(num_samples):
        response_dict = ppmac.send_receive_low(cmd_list)
        received_ += len(response_dict)

        dt = time.time() - loop_start

        sum += dt
        timeArray.append(dt)

        loop_start = time.time()

    ms_per_cmd = (time.time() - start_time) * 1000 / (num_samples * len(cmd_list))
    cmd_per_s = (num_samples * len(cmd_list)) / (time.time() - start_time)
    logging.info(
        f"received={received_}, total time {time.time()-start_time:.3f}s, "
        f"ave time per cmd {ms_per_cmd:.3}ms/cmd, average throughput = {cmd_per_s:.0f}cmd/s"
    )

    return timeArray



if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    timeArray = test_low_level()

    
    # import matplotlib.pyplot as plt
    # fig, axs = plt.subplots(1, 1, sharey=True, tight_layout=True)
    # axs.hist(timeArray, bins=20)
    # plt.xlabel("loop time taken bin [s]")
    # plt.ylabel("number in bin")

    # plt.figure()
    # plt.plot(timeArray)
    # plt.xlabel("loop #")
    # plt.ylabel("loop time [s]")

    # plt.show()