from ppmac_async import Aioppmac
from ppmac_async import PpmacGpascii
import pytest

def test_imports():
    dut = Aioppmac(host="172.0.0.1")

def test_remove_comments():
    """
    """
    ppmac=PpmacGpascii(host="")
    buffer_in = ["X0Y0 //comment1","X10Y10 //comment2"]
    buffer_correct = ["X0Y0","X10Y10"]
    buffer_out = ppmac.remove_comments(buffer_in)
    for i in range(len(buffer_in)):
        assert buffer_out[i] == buffer_correct[i]
