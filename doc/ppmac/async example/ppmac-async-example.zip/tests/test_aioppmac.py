"""test the aioppmac routines """
import os
import asyncio
import time
import pytest
import logging
from ppmac_async import Aioppmac

# if you have hardware you can test by :
# set hardware IP address environment variable 
#  "PPMAC_TEST_IP", eg = "xx.xx.xx.xx"
#  then run "poetry run pytest -v -k hardware"

async def send_one():
    """test send one commnad"""
    ppmac_test_IP = os.getenv("PPMAC_TEST_IP")
    assert ppmac_test_IP != None, "need ENV var = PPMAC_TEST_IP"

    appmac = Aioppmac(ppmac_test_IP)
    await appmac.start()
    start_t = time.time()
    cmd, result = await appmac.send_receive("#1p")
    logging.info(f"send_one:")
    logging.info(f"sent {cmd}, received back; {result}")
    fin_t = time.time()
    took = fin_t - start_t
    # logging.info(result1)
    # logging.info(result2)
    logging.info(f"took={took*1000:.2f}ms, {1/took:.0f}cmd/s")
    assert result != ""
    assert took < 20, "ms"
    #await 
    appmac.close_loop()


async def send_many():
    """test send many commands"""
    ppmac_test_IP = os.getenv("PPMAC_TEST_IP")
    assert ppmac_test_IP != None, "need ENV var = PPMAC_TEST_IP"
    NUM_CMDS = 100

    appmac = Aioppmac(ppmac_test_IP)
    await appmac.start()
    task1 = []
    task2 = []
    task3 = []
    task4 = []
    start_t = time.time()
    for j in range(NUM_CMDS):
        for i in range(8):
            task1.append(asyncio.create_task(appmac.send_receive(f"#{i+1}p")))

            task2.append(asyncio.create_task(appmac.send_receive(f"#{i+1}f")))
            task3.append(asyncio.create_task(appmac.send_receive(f"Motor[{i+1}].status[0]")))
            task4.append(asyncio.create_task(appmac.send_receive(f"Motor[{i+1}].status[1]")))
    # Wait until both tasks are completed (should take
    # around 2 seconds.)
    result1 = []
    result2 = []
    result3 = []
    result4 = []
    buffer = ""
    for i in range(NUM_CMDS * 8):
        result1.append(await task1[i])
        result2.append(await task2[i])
        result3.append(await task3[i])
        result4.append(await task4[i])
    fin_t = time.time()
    for i in range(NUM_CMDS * 8):
        buffer += f"{result1[i][0]},{result1[i][1]}\n"
        buffer += f"{result2[i][0]},{result2[i][1]}\n"
        buffer += f"{result3[i][0]},{result3[i][1]}\n"
        buffer += f"{result4[i][0]},{result4[i][1]}\n"

    took = fin_t - start_t
    throughput = 32 * NUM_CMDS / took
    # logging.info(result1)
    # logging.info(result2)
    logging.info(f"send_many:")
    logging.info(f"took = {took*1000:.2f}ms to send {32*NUM_CMDS}cmds, " f"{throughput:.0f}cmd/s")
    logging.info(f"sending time = {appmac.send_time:.3f}s")
    logging.info(f"rcv time = {appmac.rcv_time:.3f}s")
    logging.info(f"sent {appmac.num_sent}")
    logging.info(f"received {appmac.num_received}")
    with open("results.txt", "w") as fo:
        fo.write(buffer)
 
    appmac.close_loop()

    assert throughput > 1000, "cmd/s"


async def send_many_list():
    """test send many commands"""
    ppmac_test_IP = os.getenv("PPMAC_TEST_IP")
    assert ppmac_test_IP != None, "need ENV var = PPMAC_TEST_IP"
    NUM_CMDS = 100

    appmac = Aioppmac(ppmac_test_IP)
    await appmac.start()
    task1 = []

    start_t = time.time()
    for j in range(NUM_CMDS):
        for i in range(8):
            task1.append(
                asyncio.create_task(
                    appmac.send_receive_list(
                        [f"#{i+1}p", f"#{i+1}f", f"Motor[{i+1}].status[0]", f"Motor[{i+1}].status[1]"]
                    )
                )
            )
    # Wait until both tasks are completed (should take
    # around 2 seconds.)
    result1 = []

    buffer = ""
    for i in range(NUM_CMDS * 8):
        result1.append(await task1[i])

    fin_t = time.time()

    for result in result1:
        buffer += f"{result}\n"

    took = fin_t - start_t
    throughput = 32 * NUM_CMDS / took
    # logging.info(result1)
    # logging.info(result2)
    logging.info(f"send_many_list:")
    logging.info(f"took = {took*1000:.2f}ms to send {32*NUM_CMDS}cmds, " f"{throughput:.0f}cmd/s")
    logging.info(f"sending time = {appmac.send_time:.3f}s")
    logging.info(f"rcv time = {appmac.rcv_time:.3f}s")
    logging.info(f"sent {appmac.num_sent}")
    logging.info(f"received {appmac.num_received}")
    with open("results.txt", "w") as fo:
        fo.write(buffer)
    appmac.close_loop()

    assert throughput > 3000, "cmd/s"

@pytest.mark.hardware
def test_simple():
    ppmac_test_IP = os.getenv("PPMAC_TEST_IP")
    assert ppmac_test_IP != None, "need ENV var = PPMAC_TEST_IP"
    appmac = Aioppmac(ppmac_test_IP)
    appmac.connect()
    reply = appmac._read_until("\x06")
    logging.info(f"test_simple:")
    for i in range(8):
        cmd = f"#{i+1}p"
        appmac.send_cmd(cmd)
        reply = appmac._read_until("\x06")
        while reply == "":
            reply = appmac._read_until("\x06")
        logging.info(f"cmd={cmd}, reply={reply}")
    appmac.close()


@pytest.mark.hardware
def test_single():
    """ test send one"""

    asyncio.run(send_one())


@pytest.mark.hardware
def test_multiple():
    """ test send many"""
    
    asyncio.run(send_many())


@pytest.mark.hardware
def test_multiple_list():
    """ test send many"""

    asyncio.run(send_many_list())


def run_t():
    test_simple()
    test_single()
    test_multiple()
    test_multiple_list()


def profile_run_t():
    import cProfile

    # cProfile.run('run_t()')
    import pstats
    import io
    from pstats import SortKey

    pr = cProfile.Profile()
    pr.enable()
    # ... do something ...
    run_t()
    pr.disable()
    s = io.StringIO()
    sortby = SortKey.TIME  # total time
    # sortby = SortKey.CUMULATIVE
    ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
    ps.print_stats()
    print(s.getvalue())


if __name__ == "__main__":

    # debug log just to screen
    # logging.basicConfig(format='%(asctime)s %(message)s',
    #                    level=logging.DEBUG)
    logging.basicConfig(level=logging.INFO)

    run_t()
    # profile_run_t()
