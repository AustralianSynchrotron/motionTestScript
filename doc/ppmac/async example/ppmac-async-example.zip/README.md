# Power PMAC Tools

[![Build Status](https://ci.asci.synchrotron.org.au/api/badges/MC/ppmac-async/status.svg?ref=refs/heads/main)](https://ci.asci.synchrotron.org.au/MC/ppmac-async)

Provides asyncio commands to PowerPMAC, suitable for use with caproto.

## License

This project is confidential and NOT for public release.

## Installing

install with poetry install

## Testing

In order to do pytest requires environment variable PPMAC_TEST_IP
  "PPMAC_TEST_IP", eg = "xx.xx.xx.xx"
then run "poetry run pytest -v -k hardware"

## Troubleshooting
