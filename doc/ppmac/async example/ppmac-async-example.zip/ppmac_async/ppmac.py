""" basic ppmac functions to gpascii using paramiko """

import logging
import time
import paramiko
import select


logger = logging.getLogger(__name__)


class PpmacGpascii:
    """ basic access to ppmac using paramiko """

    def __init__(self, host):
        self.host = host
        self.rcv_buffer = ""
        self.err_buffer = [] # ""
        self.send_time = 0
        self.rcv_time = 0
        self.num_sent = 0
        self.num_received = 0
        self.prev_index =0

    def connect(self, username="root", password="deltatau"):
        try:
            self.session = paramiko.SSHClient()
            self.session.set_missing_host_key_policy(
                paramiko.AutoAddPolicy())
            self.session.connect(self.host,
                                          username=username,
                                          password=password)
            # see also paramiko timeout=self.TIMEOUT)
            logger.info("Success, connected.")
            success = True
        except paramiko.AuthenticationException:
            self.d_print("Authentication failed when connecting"
                         f"to {self.host}")
            sys.exit(1)

        # 8192 is paramiko default bufsize
        self.stdin, self.stdout, self.stderr = \
            self.session.exec_command("gpascii -2", bufsize=8192)
        
        # wait until gpascii ready
        while self._read_until("Input") == "":
            pass
        
    def _read_until(self, termstr):
        """ a non-async single non-blocking read into rcv_buffer and
        will return the string up to termstr off the buffer if available """
        # if its not already in the buffer then get more from buffer
        self.read_to_buf()

        if self.err_buffer  != [""]:
            for error in self.err_buffer:
                # error_temp = error.decode("utf-8")
                error_temp = error # .decode("utf-8")
                logger.error(f"std_err:{error_temp}") #self.err_buffer}")

            #self.err_buffer = [] #""
            assert False, f"std_err: {self.err_buffer}"

        response = self._read_buf_until(termstr)  # fast read from buffer
        if response != "":
            self.num_received += 1
        return response

    def _read_buf_until(self, termstr):
        ack_pos = self.rcv_buffer.find(termstr)
        if ack_pos == -1:
            return ""
        response = self.rcv_buffer[0:ack_pos]
        ack_pos = ack_pos + len(termstr)  # increment past "\x06"

        if ack_pos >= len(self.rcv_buffer):
            ack_pos = len(self.rcv_buffer)

        self.rcv_buffer = self.rcv_buffer[ack_pos:]

        return response

    def read_to_buf(self):
        """just get any data off ssh and put into local buffer """
        st_time = time.time()
        # non-blocking read
        self.rcv_buffer += self.nb_read()

        errors = self.nb_read_stderr()

        errors = errors.split("\n")  

        self.err_buffer = errors

        self.rcv_time += time.time() - st_time

    def nb_read(self):
        """non-blocking read
        returns whatever in stdout, up to 1024 bytes"""
        buffer = ""
        # Only get data if there is data to read in the channel
        if self.stdout.channel.recv_ready():
            rl, wl, xl = select.select([self.stdout.channel], [], [], 0.0)
            if len(rl) > 0:
                buffer = self.stdout.channel.recv(1024).decode("utf-8")

        return buffer

    def nb_read_stderr(self):
        """ non-blocking read of stderr"""
        buffer = ""
        # Only get data if there is data to read in the channel
        if self.stderr.channel.recv_stderr_ready():
            buffer = self.stderr.channel.recv_stderr(1024).decode("utf-8")
            print(f"received(stderr): {buffer}")
        return buffer


    def send_receive_low(self, cmd_list, stripchar="\r\n\x06"):
        """ send a list of commands & receive a list back"""
        for cmd in cmd_list:
            self.send_cmd(cmd)

        out_dict = {}
        reply_num = 0
        while reply_num < len(cmd_list):
            response = self._read_until("\x06")
            if response != "":
                cmd_response = self.process_response(response, cmd_list[reply_num], stripchar=stripchar)
                out_dict[cmd_list[reply_num]] = cmd_response
                reply_num += 1

        return out_dict

    def send_cmd(self, cmd):
        """ send """
        st_time = time.time()
        logger.debug(f"sendin {cmd}")
        self.num_sent += 1
        self.stdin.write(cmd + "\n")
        self.stdin.flush()
        self.send_time += time.time() - st_time

    def process_response(self, response, cmd_expected, stripchar="\r\n\x06"):
        """ takes raw string from ppmac, and finters and checks
        returns [cmd, response] pair"""
        # strip off undesired char
        for char in stripchar:
            response = response.replace(char, "")
    
        if response == "":
            #assert response != "", 
            logger.info(f"sync error, empty response from cmd= {cmd_expected}")

        if response.find("=") != -1:
            cmd_response = [cmd_expected, response.split("=")[1]]
            intended_cmd = cmd_expected.lower()
            cmd_received = response.split("=")[0].lower()
            assert cmd_received == intended_cmd, f"sync error, {response.split('=')[0]} != {cmd_expected}"
        else:
            cmd_response = [cmd_expected, response]
        
        return cmd_response

        
    def send_motion_prog(self, prog_name, buffer):
        """
        buffer is a list of strings to be \\n 
        terminated when sent to the brick.
        Adds:
        "open prog xxxx" at the top, and
        "close" at the end. 
        """
        # TODO: check the buffer?

        st_time = time.time()
        buffer_reply1 = self.send_receive_low([f"open prog {prog_name}"])
        buffer_reply2 = self.send_receive_low(buffer)
        buffer_reply3 = self.send_receive_low([f"close"])

        # TODO: check reply
        #  note however that low-level will detect some errors

        time_taken =  time.time() - st_time
        print(f"sending took={time_taken:0.1f}s")

        # TODO: return success/fail status. check with a readback?

    def get_motion_prog(self, prog_name):
        """ get a readback
        """
        program_list_dict = self.send_receive_low([f"list prog {prog_name}"], stripchar="\r\x06")
        readback_prog = program_list_dict[f"list prog {prog_name}"][1]
        readback_prog = readback_prog.split("\n")

        # TODO: return success/fail status.
        return readback_prog

    @staticmethod
    def remove_comments(buffer):
        """remove empty lines and comments
        """
        valid_lines = []
        for i in range(len(buffer)):
            line = buffer[i].split("//")[0]
            line = line.replace(";","")
            line = line.replace(" ","")
            #print(line)
            if line == "":
                continue
            valid_lines.append(line)
        return valid_lines

    def close(self):
        logger.info("closing ssh")
        self.stdout.close()
        self.stdin.close()
        self.stderr.close()

        # if self.gpascii_paramiko_session is not None:
        self.session.close()
        logger.info(f"ssh Exited")
