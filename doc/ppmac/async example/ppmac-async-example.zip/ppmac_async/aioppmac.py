""" asyncio access to power pmac.
 use logging module for debugging. """
import time
import asyncio
import logging
from collections import deque

from ppmac_async.ppmac import PpmacGpascii

logger = logging.getLogger(__name__)

class Aioppmac(PpmacGpascii):
    """ asyncio access to ppmac """

    def __init__(self, host):
        super().__init__(host)

    async def start(self):
        self.queue_send = asyncio.Queue()
        # the list of commands we have sent and are awaiting a reply
        self.cmd_que = deque([])
        self.queue_loop_shutdown = asyncio.Queue()

        self.rcv_buffer = ""
        self.queue_ready = asyncio.Queue()
        asyncio.create_task(self.ssh_loop())

        await self.queue_ready.get()
        self.queue_ready.task_done()

        logger.info("started, ready")

    async def send_receive_list(self, cmd_list):
        """ send a command & receive a list"""

        # TODO dont do repeat cmds here
        queue_rcv = asyncio.Queue()
        logger.debug(f"send cmd list={cmd_list}, rcv_id={id(queue_rcv)}")
        self.queue_send.put_nowait([cmd_list, queue_rcv])

        result_list = await queue_rcv.get()

        queue_rcv.task_done()
        logger.debug(f"received {result_list}, rcv_id={id(queue_rcv)}")

        for cmd in cmd_list:
            assert cmd == result_list[cmd][0], f"{cmd} != {result_list[cmd][0]} "
            # if there is something wrong with the send loop this will fail

        return result_list

    async def send_receive(self, cmd):
        """
            Send a command & receive a reply, this sends a command to the ppmac
        Aasumptions:
            we are relying on the GIL here to make sure we
            have exclusive access to send to the ppmac.
            we also expect the stdin.write to be non-blocking
        """
        result = await self.send_receive_list([cmd])
        result = result[cmd]

        return result

    async def ssh_loop(self):
        """
            This is the main process that must be running.
            It holds the conection open to send/receive commands doing this enables ~5k msgs/s,
            whereas if we had to connect every time it would take 360ms every msg,
            or send-receive one message ~5ms/msg
        """
        shutdown = False

        logger.info("starting up")

        self.connect()

        # time.sleep(0.001)  # yield to other thread
        await asyncio.sleep(0.001)  # yield to other thread

        self.queue_ready.put_nowait("ready")
        # await self.queue_ready.put("ready")
        out_dict = {}
        num_rcvd = 0
        while not shutdown:
            # check for shutdown request
            shutdown = self.check_shutdown()

            # new data received
            result = self._read_until("\x06")
            while result != "":
                # this is reply from stdout
                cmd_expected, queue_rcv, num_expected = self.cmd_que.popleft()

                num_rcvd += 1  # dont use length of dict, incase there are dupes

                response = result
                cmd_response = self.process_response(response, cmd_expected)
                out_dict[cmd_expected] = cmd_response
                #if len(out_dict) >= num_expected:
                if num_rcvd >= num_expected:
                    queue_rcv.put_nowait(out_dict)
                    out_dict = {}
                    num_rcvd = 0

                result = self._read_until("\x06")

            # send request
            result = self.get_any_cmd()
            while result != []:
                # this is a new value to send
                # format [cmd, queue_rcv]
                cmd_list, queue_rcv = result
                for cmd in cmd_list:
                    self.cmd_que.append([cmd, queue_rcv, len(cmd_list)])
                    self.send_cmd(cmd)

                result = self.get_any_cmd()

            #  yeild to other tasks
            await asyncio.sleep(0.0001)

            # TODO when this loop has a runtime error or assert, then reconnect or "exit(1)"

    def check_shutdown(self):
        """ Returns true if loop should shutdown """
        try:
            self.queue_loop_shutdown.get_nowait()
            self.queue_loop_shutdown.task_done()
        except asyncio.QueueEmpty:
            return False
        return True

    def get_any_cmd(self):
        """ If any commands waiting in the queue this will return them """
        new_cmd = []
        try:
            new_cmd = self.queue_send.get_nowait()
            self.queue_send.task_done()
        except asyncio.QueueEmpty:
            pass  # no others to send
        return new_cmd

    def close_loop(self):
        logger.info("shutting down loop..")
        self.queue_loop_shutdown.put_nowait("shutdown")
        time.sleep(0.1)
        self.close()
