## Overview

BaseConfig is a code template developed in the Australian Synchrotron by Control Systems team, for OMRON PowerPmac (ppmac) family of controllers.
It provides a fully functional ppmac project that configures an 8x channel PowerBrickLV controller with:
- 8 open-loop steppers with absolute 32 bit BiSS-C readbacks
- A set of additional runtime protections: Unexpected limit, SlipError, MaxActSpeed
- A set of protections for wrong configuration
- 4 coordinate systems defined as linear slits
- AS2 EPICS software stack support
- Dual readback per motor. The secondary "reference" readback is used for Slip protection as well as performance measurement, and it is available at EPICS.

Additionally, BaseConfig provides a set of "Motor Templates" implemented using "PMAC Script Language". These templates provide quick and easy motor settings using native *.pmh files the ppmac project, which can be tested on the fly without needing to download the project. The templates out of the box include:
    - Open loop stepper with encoder readback
    - Closed loop stepper with encoder feedback
    - Position closed-loop stepper (velocity open-loop)
    - Brushed DC motors and Voice Coil
    - Brushless DC motors (open template) with single and dual encoders


## Download and customise

1- Download the repo (don't clone) and copy onto your project directory. If the project directory already contains a ppmac project, then BaseConfig modules in that directory will be overwritten with the newer (or older) versions. Beware that any files which share BaseConfig file name convention (*_base* in filename) may get overwritten, so you should not apply any changes to any of these files. Copy/rename them if needed.   

2- Make a copy of "template_base.ppproj" with your specific project name, open it in ppmac IDE while connected to the PowerBrickLV. Note that the template_base.PowerPmacSuite_sln would still point to "template_base.ppproj" which makes it un-loadable after you renamed the project. You can create or rename this solution file if you need one.

4- Wipe the existing configuration of the controller, using `$$$***` followed by `save` and `$$$` from terminal.

5- "Clean" and "Build and Download All Programs" of the project into the ppmac controller.

6- from terminal `save` and restart `$$$`.


At this stage you will have a consistent configuration with default settings out of the box. You can setup the epics IOC if that is the case, and after checking the whole software stack, start customising :

- Motors: 8 open-loop steppers, at 0.5A, with 5nm BiSS-C encoder as reference readback. Rename (see * below) and set actual values in `a?- *_example_base.pmh` template files for your specific application.
- Protection settings and diagnosis variables
- Coordinate systems: 4 linear Size and Centre slit coordinate systems defined on axes 1-2, 3-4, 5-6 and 7-8. Rename (see * below) and customise relevant `cs?- *_example_base.pmh` files for your specific application.

- Epics motor record and extra functions support for AS2 epics software stack including:
    - extended motor and controller fault and status
    - homing routines using default homing plcs e.g. ppmac_sln\PMAC Script Language\PLC Programs\motor1_home_base.plc. If needed, you can rename (see * below) and customise relevant `motor?_home_base.plc` files for your specific application.

- Additional tools 
    - Axis and brick level WatchLists with BaseConfig specific variables, `Watch_Status_?_base.wtb`
    - Motion test plc



* to customise a base configuration file, use ppmac IDE's Solution Explorer:
    Right-Click and "Rename" file to project specific name without "_base" in their filename.
    example: ppmac_sln\PMAC Script Language\Global Includes\a1- stepper_example_base.pmh  -- rename in IDE -->  ppmac_sln\PMAC Script Language\Global Includes\a1- stepper_myProject.pmh
    For plc files, do not change the actual plc name which is defined in the file, e.g `OPEN plc motor1_home`


## Configure 
Change configurations of the motors using the template settings. PPMAC BaseConfig User's Guide and PPMAC BaseConfig Template deployment and updating process for further details.

You can "try" your settings simply by setting the parameters via the terminal, and then running config plc `enable plc config` followed by `enable plc updates` to activate the new configuration without downloading code. All of the 8 motors will be killed.

This configuration will hold in memory until the pmac is restarted, when the saved project files are applied. The current configuration in memory can be saved onto *.cfg files e.g. ppmac_sln\Configuration\pp_save.cfg using `save` command, but will be overwritten by the downloaded and saved project files. Therefore we recommend to change the settings already in motor's .pmh template, then select and drop onto the terminal. Then you can save the .pmh template in the project if the configuration worked. 

## Source
External AS Production Release for vendors: AustralianSynchrotron/ppmac-baseconfig (github.com)
Internal AS Production Release for beamlines:  Perforce - //ASP/tec/mc/ppmac/trunk/ppmac-baseconfig/
Internal AS BitBucket devel source:  Browse Motion Control / ppmac-baseConfig - Bitbucket (synchrotron.org.au)        Branch Name: BaseModule
Internal AS development/testing workspace: //ASP/opa/int/ctrls/ppmac-baseconfig/


